#pragma once

${NAMESPACES_OPEN}
class ${NAME} {

};

${NAMESPACES_CLOSE}